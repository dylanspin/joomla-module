DROP TABLE IF EXISTS `#__info_database`;

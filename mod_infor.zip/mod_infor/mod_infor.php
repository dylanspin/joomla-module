<?php
/**
 * @category   informatie module
 * @author     Dylan Spin dylanspin100@hotmail.com
 * @copyright   Copyright (C) 2019
 */

 defined('_JEXEC') or die;

// Include the syndicate functions only once
 require_once dirname(__FILE__) . '/helper.php';

 // $hello = modHelloWorldHelper::getHello($params);
 require JModuleHelper::getLayoutPath('mod_infor');
?>
